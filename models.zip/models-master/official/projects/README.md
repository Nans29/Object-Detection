# TensorFlow Model Garden Modeling Projects

This directory contains projects using TensorFlow Model Garden Modeling
libraries.

## Projects

*   [NHNet](nhnet):
    [Generating Representative Headlines for News Stories](https://arxiv.org/abs/2001.09386)
    by Gu et al, 2020

